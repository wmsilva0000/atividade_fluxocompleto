<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dados</title>
</head>
<body>
    <h1>Dados Pessoais</h1>
    <p>Nome: {{ $nome }}</p>
    <p>Sobrenome: {{ $sobrenome }}</p>
    <p>Idade: {{ $idade }}</p>
    <p>Rm: {{ $rm }}</p>
    <p>Gênero: {{ $genero }}</p>
    <p>Endereço: {{ $endereco }}</p>
</body>
</html>