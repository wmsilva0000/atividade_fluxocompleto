<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Operacoes</title>
</head>
<body>
  <h1>O resultado da Operação é <?php echo e($resultado); ?></h1>
</body>
</html><?php /**PATH C:\Users\aluno\rotas\resources\views/operacoes.blade.php ENDPATH**/ ?>