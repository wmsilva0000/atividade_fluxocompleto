<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dados</title>
</head>
<body>
    <h1>Dados Pessoais</h1>
    <p>Nome: <?php echo e($nome); ?></p>
    <p>Sobrenome: <?php echo e($sobrenome); ?></p>
    <p>Idade: <?php echo e($idade); ?></p>
    <p>Rm: <?php echo e($rm); ?></p>
    <p>Gênero: <?php echo e($genero); ?></p>
    <p>Endereço: <?php echo e($endereco); ?></p>
</body>
</html><?php /**PATH C:\Users\aluno\rotas\resources\views/dados.blade.php ENDPATH**/ ?>